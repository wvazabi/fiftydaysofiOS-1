import UIKit

var greeting = "Hello, playground"
var x = 28
let constant = "Constant"

var p = 132

var y: Int


var num1 = 2
var num2 = 2.8

var sum = Double(num1) + num2


var sumStr = greeting + " " + constant

var e = ""
var n: Int? = nil

n = 2

n = nil

var pi: Float = 3.14

//pi = nil














